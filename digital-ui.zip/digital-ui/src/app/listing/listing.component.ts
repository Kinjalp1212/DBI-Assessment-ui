import { Component, OnInit } from '@angular/core';
import { HomeProductService } from './listing.service';
@Component({
  selector: 'app-listing-page',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.scss']
})
export class ListingComponent implements OnInit {
  productData: any;
  constructor(
    private homeProductService : HomeProductService 
) { 
  
}
ngOnInit(){
  this.homeProductService.getJSON().subscribe(data => {
       this.productData = data;
       console.log(this.productData);
       return this.productData;
   });
}

}
