import {NgModule} from "@angular/core";
import {ListingComponent} from "./listing.component";
import {RouterModule, Routes} from "@angular/router";
import {HomeProductService} from "./listing.service";
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
const routes: Routes = [
  {
    path: '',
    component: ListingComponent
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes),HttpClientModule,CommonModule,FormsModule],
  declarations: [ListingComponent],
  providers: [HomeProductService]
})
export class ListingModule {}
